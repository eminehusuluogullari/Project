package odev2;

import java.util.*;

public class Main_2216 
{
	    // metnı ben yazdım
	    static String metin ="eminerjhhfgd  susss icc fhkjd. jherfgdsk icc susss djfkgh. fghsjlafk susss ghfskd. emine hsdjjgfkhs. emine susss jshdf icc ksjl."; 

	    public static void main(String[] args) 
	    {
	        Scanner scanner = new Scanner(System.in);
	        
	        while (true) 
	        {
	            System.out.println("secim yapinn");
	            System.out.println("1. her kelimeden kac tane var bul");
	            System.out.println("2. cumle sayisni bul ve cumlelerı alt alta yaz");
	            System.out.println("3. cumllerin ilk ve son kelımesını degıstır");
	            System.out.println("0. cikis yapp");
	            
	            int secim = scanner.nextInt();
	            
	            switch (secim) 
	            {
	                case 1:
	                    kelimeTekrar();
	                    break;
	                case 2:
	                    cumleSayisi();
	                    break;
	                case 3:
	                    ilkSonKelimeDegis();
	                    break;
	                case 0:
	                    System.out.println("cikiyoruzzz");
	                    return;
	                default:
	                    System.out.println("hatali giriş yaptiniz");
	            }
	        }
	    }

	    //kac kelıme var aynından hepala 
	    public static void kelimeTekrar() 
	    {
	        String[] kelimeler = metin.toLowerCase().split("\\W+"); //tolowewr kucuk harfe cevır splıt ayırır
	        
	        Map<String, Integer> kelimeSayisi = new HashMap<>(); //hashmap kelıme addedını sayıyormus
	        
	        for (String kelime : kelimeler) //foreach ıle donduruyoruz
	        {
	        	//getordedefault kelıme oneceden cıktıysa sayıyı artırmak ıcındır
	        	// put lu kısım gelen degrı gunccler yenı deger koyar 
	            kelimeSayisi.put(kelime, kelimeSayisi.getOrDefault(kelime, 0) + 1);
	        }
	  
	        // hashamap lısteye cevrılır ve sıralama butda olur
	        List<Map.Entry<String, Integer>> kelimeListesi = new ArrayList<>(kelimeSayisi.entrySet());
	       //hazır sıarlama fonksıyonu kullandık burda sort
	        
	        kelimeListesi.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
	        
	     // istennen 3 kelımeyı yazdııroruz
	        System.out.println("istenen en cok kullanıla kelımler");

	        for (int i =0;i <3; i++) 
	        {
	            if (i < kelimeListesi.size()) 
	            {
	            	System.out.println((i + 1)+ "."+ kelimeListesi.get(i).getKey() + ": " + kelimeListesi.get(i).getValue() + " kez.");
	        	}}

	    }

	    


	    // 2. cumlelrı alt alta yazcaz
	    public static void cumleSayisi() 
	    {
	        String[] cumleler = metin.split("\\.");
	        System.out.println("Cümle sayısı: " + cumleler.length); //dızının adıyla uzunluk adet hesaplıor
	        
	        for (String cumle:cumleler) 
	        {
	            System.out.println(cumle.trim() + "."); //bosluk kaldırır
	        }
	    }

	    // ilk ve son kelımeyı degıstır cumlede
	    public static void ilkSonKelimeDegis() 
	    {
	        String[] cumleler = metin.split("\\."); //ayrımamız 
	        
	        for (String cumle: cumleler) 
	        {
	            if (cumle.trim().isEmpty()) 
	            	{
	            		continue;
	            	}
	            // trım bolsuk sıler
	            // isEmpyt stırnge bakar bossa  true kabul eder
	            String[] kelimeler =cumle.trim().split("\\s+");
	            String ilkKelime=kelimeler[0]; //ilk ındexle cagırır
	            String sonKelime = kelimeler[kelimeler.length - 1]; //son ındexle son kelıme cagırılır

	            kelimeler[0] =sonKelime.substring(0, 1).toUpperCase()+ sonKelime.substring(1).toLowerCase();
	            //				son kelımenın indexını alır 1 ve 0 
	            // toupper = buyuk harfe cevırır
	            
	            kelimeler[kelimeler.length - 1] = ilkKelime.toLowerCase(); //atama yapıyoruz

	            System.out.println(String.join("-",kelimeler) );
	        }
	    }
	}




