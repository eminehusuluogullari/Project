package paket2;

public class Beverages extends Urun {
    public Beverages(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari) {
        super(adi, kategoriIndex, birimAgirligi, birimFiyati, stokMiktari);
    }

    void icecekKaloriHesapla(double gram) {
        double kalori = gram * 0.5;
        System.out.println(adi + " - Kalori: " + kalori + " kcal");
    }

    public void icecekKaloriHesaplaYazdir(double gram) {
        icecekKaloriHesapla(gram);
    }
}
