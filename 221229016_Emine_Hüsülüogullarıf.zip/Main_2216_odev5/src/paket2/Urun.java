package paket2;

public class Urun {
    protected String adi;
    protected int kategoriIndex;
    protected String birimAgirligi;
    protected double birimFiyati;
    protected int stokMiktari;

    public Urun(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari) {
        this.adi = adi;
        this.kategoriIndex = kategoriIndex;
        this.birimAgirligi = birimAgirligi;
        this.birimFiyati = birimFiyati;
        this.stokMiktari = stokMiktari;
    }

    protected String getAdi() {
        return adi;
    }

    protected double getBirimFiyati() {
        return birimFiyati;
    }

    protected int getStokMiktari() {
        return stokMiktari;
    }

    public String toString() {
        return "Adi: " + adi + ", Kategori Index: " + kategoriIndex + ", Birim Agirligi: " + birimAgirligi +
               ", Birim Fiyati: " + birimFiyati + ", Stok Miktari: " + stokMiktari;
    }
}
