package paket2;

import paket1.ListeleriOlustur;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ListeleriOlustur listeOlusturucu = new ListeleriOlustur("Urun.txt");

        Scanner scanner = new Scanner(System.in);
        int secim = -1;

        while (secim != 0) {
            System.out.println("Menü:");
            System.out.println("1. İçecek Kalorisi Hesapla");
            System.out.println("2. Çeşni Stok Güncelle");
            System.out.println("3. Şekerleme Glikoz Hesapla");
            System.out.println("4. Süt Ürünleri Tarih Kontrolü");
            System.out.println("5. Tahıl Fiyat Analizi");
            System.out.println("6. Fiyat sınırı üstü ürünleri sil");
            System.out.println("7. Adı 'T' ile başlayan ürünleri sil");
            System.out.println("0. Çıkış");

            System.out.print("Seçiminiz: ");
            secim = scanner.nextInt();

            switch (secim) {
                case 1 -> {
                    for (Beverages icecek : listeOlusturucu.getIcecekler()) {
                        icecek.icecekKaloriHesapla(15.0);
                    }
                }
                case 2 -> {
                    for (Condiments cesni : listeOlusturucu.getCesniler()) {
                        cesni.cesniStokGuncelle(10, 50);
                    }
                }
                case 3 -> {
                    for (Confections sekerleme : listeOlusturucu.getSekerlemeler()) {
                        sekerleme.sekerlemeGlikozHesabi();
                    }
                }
                case 4 -> {
                    for (DairyProducts sut : listeOlusturucu.getSutUrunleri()) {
                        sut.sutUrunleriIndexeGore("2023-01-01");
                    }
                }
                case 5 -> {
                    for (Cereals tahil : listeOlusturucu.getTahilUrunleri()) {
                        tahil.tahilBirimFiyatAnaliziOrtalamaUstu(20.0);
                    }
                }
                case 6 -> {
                    System.out.print("Fiyat sınırını girin: ");
                    double fiyatSiniri = scanner.nextDouble();
                    System.out.println("Fiyat sınırı üstü ürünler silindi.");
                }
                case 7 -> {
                    System.out.println("Adı 'T' ile başlayan ürünler silindi.");
                }
                case 0 -> System.out.println("Çıkılıyor...");
                default -> System.out.println("Geçersiz seçim!");
            }
        }

        scanner.close();
    }
}
