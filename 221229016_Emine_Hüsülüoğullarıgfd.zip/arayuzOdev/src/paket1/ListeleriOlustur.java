package paket1;
import java.io.*;
import java.util.*;

import paket2.Beverages;
import paket2.Condiments;
import paket2.Confections;
import paket2.DairyProducts;
import paket2.Cereals;

public class ListeleriOlustur {
    private List<Beverages> icecekler = new ArrayList<>();
    private List<Condiments> cesniler = new ArrayList<>();
    private List<Confections> sekerlemeler = new ArrayList<>();
    private List<DairyProducts> sutUrunleri = new ArrayList<>();
    private List<Cereals> tahilUrunleri = new ArrayList<>();

    public ListeleriOlustur(String dosyaAdi) {
        try (BufferedReader reader = new BufferedReader(new FileReader(dosyaAdi))) {
            String line;
            reader.readLine(); // Başlık satırını atlıyoruz

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\t"); // Tab ile ayırıyoruz
                if (parts.length != 5) {
                    continue; // Satırda eksik veri varsa geçiyoruz
                }

                String adi = parts[0];
                int kategoriIndex = Integer.parseInt(parts[1]);
                String birimAgirligi = parts[2];
                double birimFiyati = Double.parseDouble(parts[3]);
                int stokMiktari = Integer.parseInt(parts[4]);

                switch (kategoriIndex) {
                    case 1:
                        icecekler.add(new Beverages(adi, kategoriIndex, birimAgirligi, birimFiyati, stokMiktari));
                        break;
                    case 2:
                        cesniler.add(new Condiments(adi, kategoriIndex, birimAgirligi, birimFiyati, stokMiktari));
                        break;
                    case 3:
                        sekerlemeler.add(new Confections(adi, kategoriIndex, birimAgirligi, birimFiyati, stokMiktari));
                        break;
                    case 4:
                        sutUrunleri.add(new DairyProducts(adi, kategoriIndex, birimAgirligi, birimFiyati, stokMiktari));
                        break;
                    case 5:
                        tahilUrunleri.add(new Cereals(adi, kategoriIndex, birimAgirligi, birimFiyati, stokMiktari));
                        break;
                    default:
                        System.out.println("Geçersiz kategori index: " + kategoriIndex);
                }
            }
        } catch (IOException e) {
            System.out.println("Dosya okunurken hata: " + e.getMessage());
        }
    }

    public List<Beverages> getIcecekler() {
        return icecekler;
    }

    public List<Condiments> getCesniler() {
        return cesniler;
    }

    public List<Confections> getSekerlemeler() {
        return sekerlemeler;
    }

    public List<DairyProducts> getSutUrunleri() {
        return sutUrunleri;
    }

    public List<Cereals> getTahilUrunleri() {
        return tahilUrunleri;
    }
}
