package paket2;

public class Condiments extends Urun {
    public Condiments(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari) {
        super(adi, kategoriIndex, birimAgirligi, birimFiyati, stokMiktari);
    }

    public void cesniStokGuncelle(int limitStok, int hedefStok) {
        if (stokMiktari < limitStok) {
            stokMiktari = hedefStok;
            System.out.println(adi + " - Stok miktarı güncellendi. Yeni stok: " + stokMiktari);
        } else {
            System.out.println(adi + " - Stok güncellenmedi. Mevcut stok: " + stokMiktari);
        }
    }
}

