package paket2;

public class Confections extends Urun {
    public Confections(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari) {
        super(adi, kategoriIndex, birimAgirligi, birimFiyati, stokMiktari);
    }

    public void sekerlemeGlikozHesabi() {
        double glikoz = birimFiyati * 0.2;
        System.out.println(adi + " - Glikoz: " + glikoz + " gr");
    }
}
