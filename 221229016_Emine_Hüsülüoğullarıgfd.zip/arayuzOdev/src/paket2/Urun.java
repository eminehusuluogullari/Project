package paket2;

public abstract class Urun implements IUrun {
    protected String adi;
    protected int kategoriIndex;
    protected String birimAgirligi;
    protected double birimFiyati;
    protected int stokMiktari;

    public Urun(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari) {
        this.adi = adi;
        this.kategoriIndex = kategoriIndex;
        this.birimAgirligi = birimAgirligi;
        this.birimFiyati = birimFiyati;
        this.stokMiktari = stokMiktari;
    }

    @Override
    public void stokEkle(int miktar) {
        stokMiktari += miktar;
    }

    @Override
    public void stokCikar(int miktar) {
        stokMiktari = Math.max(0, stokMiktari - miktar);
    }

    @Override
    public void urunBilgisiYazdir() {
        System.out.println("Adi: " + adi + ", Kategori Index: " + kategoriIndex +
                           ", Birim Agirligi: " + birimAgirligi + ", Birim Fiyati: " + birimFiyati +
                           ", Stok Miktari: " + stokMiktari);
    }

    @Override
    public void fiyatGuncelle(double yeniFiyat) {
        birimFiyati = yeniFiyat;
    }
}
