package paket2;

public class Cereals extends Urun {
    public Cereals(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari) {
        super(adi, kategoriIndex, birimAgirligi, birimFiyati, stokMiktari);
    }

    public void tahilBirimFiyatAnaliziOrtalamaUstu(double ortalamaFiyat) {
        if (birimFiyati > ortalamaFiyat) {
            System.out.println(adi + " - Fiyat analizi: Bu ürün ortalama fiyatın üstünde.");
        } else {
            System.out.println(adi + " - Fiyat analizi: Bu ürün ortalama fiyatın altında.");
        }
    }
}
