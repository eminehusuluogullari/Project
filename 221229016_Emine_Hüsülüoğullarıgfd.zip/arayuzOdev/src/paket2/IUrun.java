package paket2;

public interface IUrun {
    void stokEkle(int miktar);
    void stokCikar(int miktar);
    void urunBilgisiYazdir();
    void fiyatGuncelle(double yeniFiyat);
}
