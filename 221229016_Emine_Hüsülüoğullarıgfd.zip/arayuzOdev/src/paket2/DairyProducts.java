package paket2;

public class DairyProducts extends Urun {
    public DairyProducts(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari) {
        super(adi, kategoriIndex, birimAgirligi, birimFiyati, stokMiktari);
    }

    public void sutUrunleriIndexeGore(String tarih) {
        System.out.println(adi + " - Tarih kontrolü: Ürün tarihi " + tarih + " ile kontrol ediliyor.");
    }
}
