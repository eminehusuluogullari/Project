package paket2;

import paket1.ListeleriOlustur;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
    	String dosyaYolu = "C:/Users/MONSTER/Desktop/java/ödev/arayuzOdev/Urun.txt";
    	ListeleriOlustur listeOlusturucu = new ListeleriOlustur(dosyaYolu);

        Scanner scanner = new Scanner(System.in);
        int secim = -1;

        while (secim != 0) {
            System.out.println("Menü:");
            System.out.println("1. İçecek Kalorisi Hesapla");
            System.out.println("2. Çeşni Stok Güncelle");
            System.out.println("3. Şekerleme Glikoz Hesapla");
            System.out.println("4. Süt Ürünleri Tarih Kontrolü");
            System.out.println("5. Tahıl Fiyat Analizi");
            System.out.println("0. Çıkış");

            System.out.print("Seçiminiz: ");
            secim = scanner.nextInt();

            switch (secim) {
                case 1 -> listeOlusturucu.getIcecekler().forEach(icecek -> icecek.icecekKaloriHesapla(15.0));
                case 2 -> listeOlusturucu.getCesniler().forEach(cesni -> cesni.cesniStokGuncelle(10, 50));
                case 3 -> listeOlusturucu.getSekerlemeler().forEach(sekerleme -> sekerleme.sekerlemeGlikozHesabi());
                case 4 -> listeOlusturucu.getSutUrunleri().forEach(sut -> sut.sutUrunleriIndexeGore("2023-01-01"));
                case 5 -> listeOlusturucu.getTahilUrunleri().forEach(tahil -> tahil.tahilBirimFiyatAnaliziOrtalamaUstu(20.0));
                case 0 -> System.out.println("Çıkılıyor...");
                default -> System.out.println("Geçersiz seçim!");
            }
        }

        scanner.close();
    }
}
