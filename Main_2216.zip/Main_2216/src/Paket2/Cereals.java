package Paket2;

import java.util.ArrayList;

import Paket2.Cereals;

public class Cereals extends Urun //urunden kalıtılmıs demek
{	
	private String kategoriAdi;
	private String detayBilgisi;
	
	public String getDetay() //Get Metodu:Bir özelliğin değerini döndüren bir metottu
	{                        //Set Metodu:Bir özelliğe değer atayan bir metottur
		return this.detayBilgisi;
	}
	
	public String getKategoriAdi() 
	{
		return this.kategoriAdi;
	}
	
	
	private static void  HububatSil(ArrayList<Cereals>liste ,String urunAdi)
	{
		for (Cereals urun : liste) 
		{
			if(urun.getAdi()==urunAdi)
			{
				System.out.println("\n  "+urun.getAdi()+"  silindi\n");
				liste.remove(liste.indexOf(urun)); //silmek demek 
			}
		}
	}
	
	public Cereals() //busınıdın 2 farklı ozelleıgı oldugu ıcın buraya konstructer acıyoruz
	{
		this.kategoriAdi="Tah�l";
		this.detayBilgisi="Tah�l detay";
	}
}