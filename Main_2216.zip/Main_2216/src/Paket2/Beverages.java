package Paket2;

public class Beverages 
{

	private static void IcecekBirimAgirlikGuncelle(String yeniAgirlik)
	{
		
	}


}
