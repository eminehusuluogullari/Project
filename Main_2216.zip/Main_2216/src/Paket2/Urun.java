package Paket2;

import java.util.ArrayList;

public class Urun 
{
	protected String ad;
	protected String birimAgirligi;
	protected int kategoriIndex;
	protected double birimFiyati;
	protected int stokMiktari;
	
	public void setAdi(String adi) 
	{
		this.ad=adi;
	}
	public void setAgirlik(String agirlik) 
	{
		this.birimAgirligi=agirlik;
	}

	public void setStok(int stok) 
	{
		this.stokMiktari=stok;;
	}
	public void setfiyat(double yeniFiyat) 
	{
		this.birimFiyati=yeniFiyat;
	}
	public void setkategoriIndex(int index) 
	{
		this.kategoriIndex=index;
	}
	
	public String getAdi() 
	{
		return this.ad;
	}
	public String getagirlik() 
	{
		return this.birimAgirligi;
	}
	public int getindex() 
	{
		return this.kategoriIndex;
	}
	public int getstok() 
	{
		return this.stokMiktari;
	}
	public double getfiyat() 
	{
		return this.birimFiyati;
	}
	
	
	private static void UrunleriFiyataGoreSil(ArrayList<Cereals>liste) 
	{
		int mak=Integer.MIN_VALUE;
		int min=Integer.MAX_VALUE;
		
		for (Cereals urun : liste) //ceralsdan alınan her urunu lısteye ekleıyruz 
		{
			if(urun.getfiyat()> min  && urun.getfiyat()< max ) //eger stok mıktara esıtse bundan sılme yapıcaz 
			{
				System.out.println("\n  "+ urun.getAdi()+"  silindi \n");
				liste.remove(liste.indexOf(urun)); //silmek demek 
			}
		}
	}
	
	
	private static void UrunKategorikStokGuncelle(ArrayList<Cereals>liste , int x)
	{
		for (Cereals urun : liste) //ceralsdan alınan her urunu lısteye ekleıyruz 
		{
			urun.getfiyat() =urun.getfiyat * (x/100);
			System.out.println(urun.getAdi()+"\t"+urun.getindex()+"\t"+urun.getagirlik()+"\t"+urun.getfiyat()+"\t"+urun.getstok()+"\t"+urun.getKategoriAdi()+"\t"+urun.getDetay());
			//okuma yaparken get kullanılır getır gıbı dusun metnı 
		}
	}
}