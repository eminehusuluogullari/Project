package Paket2;

import java.util.ArrayList;

import paket2.Cereals;

public class Condiments {
	
	private static void CesniStokGuncelle(boolean Satismi, int miktar)
	{
		int index=Scanner.nextInt();
		
		for (Cereals urun : liste) 
		{
			if(urun.getstok()==miktar) 
			{	
				System.out.println("\n  "+urun.getAdi()+"  Cikartildi\n");
				liste.remove(liste.indexOf(urun)); 
			}
		}
	}

}