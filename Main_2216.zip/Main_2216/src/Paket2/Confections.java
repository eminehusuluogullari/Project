package Paket2;

public class Confections 
{
	private static void SekerlemeUrunEkle (Adi, BirimAgirligi, BirimFiyatı, StokMiktari)
	{
		
	}
	
}





