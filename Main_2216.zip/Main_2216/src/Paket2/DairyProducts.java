package Paket2;

public class DairyProducts 
{
	private static void SutUrunleriDetayEkle(String yeniDetay)
	{
		
	}
}