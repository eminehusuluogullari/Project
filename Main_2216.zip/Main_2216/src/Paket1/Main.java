//dosyadan okuma metoları olcakmıs sadece
import Paket2.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main 
{
	public static void ListeleriOlustur(ArrayList<Cereals> liste) throws IOException 
	{
		FileReader file= new FileReader("Urunler.txt"); 
		BufferedReader buffe = new BufferedReader(file);
		String satir=null;
		satir=buffe.readLine();
		satir=null;
		
		while(true) 
		{
			satir=buffe.readLine();
			
			if(satir==null) 
			{
				return;
			}
			
			String []dizi =satir.split("\t");
			
			if(Integer.valueOf(dizi[1])==5) 
			{
				Cereals urun = new Cereals();
				urun.setAdi(dizi[0]);
				urun.setAgirlik(dizi[2]);
				urun.setkategoriIndex(5);
				urun.setfiyat(Double.valueOf(dizi[3]));
				urun.setStok(Integer.valueOf(dizi[4]));
				liste.add(urun);
			}
			
		}
	}
	
	
	public static void listeOku(ArrayList<Cereals> liste) 
	{
		for (Cereals urun : liste) 
		{
			System.out.println(urun.getAdi()+ "\t"+urun.getindex()+"\t"+urun.getagirlik()+"\t"+urun.getfiyat()+"\t"+urun.getstok()+"\t"+urun.getKategoriAdi()+"\t"+urun.getDetay());
		}
	}
	
	public static void main(String[] args) throws IOException 
	{
		ArrayList<Cereals> liste = new ArrayList<Cereals>();
		UrunleriFiyataGoreSil(liste);
		UrunKategorikStokGuncelle(liste);
		IcecekBirimAgirlikGuncelle(liste);
		CesniBirimAgirlikGuncelle(liste);
		SekerlemeUrunEkle(liste);
		SutUrunleriDetayEkle(liste);
		HububatSil(liste);
		
		System.out.println("**************menu*****************");
		System.out.println("1-urunleri fiyata gore sil");
		System.out.println("2-Urun Kategorik Stok Guncelle");
		System.out.println("3-Icecek Birim Agirlik Guncelle");
		System.out.println("4-Cesni Birim Agirlik Guncelle");
		System.out.println("5-Sekerleme Urun Ekle");
		System.out.println("6-Sut Urunleri Detay Ekle");
		System.out.println("7-Hububat Sil");

		
        Scanner scanner = new Scanner(System.in);

        // Kullanıcıdan bir secim alın
        System.out.println("secim yapinn");
        int secim = scanner.nextInt();
		
		switch (secim)
		{
			case 1 : UrunleriFiyataGoreSil(liste);
			break;
			
			case 2 : UrunKategorikStokGuncelle(liste);
			break;
			
			case 3 : IcecekBirimAgirlikGuncelle(liste);
			break;
			
			case 4 : CesniBirimAgirlikGuncelle(liste);
			break;
			
			case 5 : SekerlemeUrunEkle(liste);
			break;
			
			case 6 : SutUrunleriDetayEkle(liste);
			break;
			
			case 7 : HububatSil(liste);
			break;
			
			case 8 :System.out.println("cikis yapiliyor");
			break;
		}
	}
}