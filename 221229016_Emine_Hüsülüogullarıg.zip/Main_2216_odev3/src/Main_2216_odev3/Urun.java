package Main_2216_odev3;

class Urun 
{
    String adi;
    int kategoriIndex;
    String birimAgirligi;  // agırlıgı strgn tutcaz numaradkı gıbı
    double birimFiyati;
    int stokMiktari;

    public Urun(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari) 
    {
        this.adi = adi;
        this.kategoriIndex = kategoriIndex;
        this.birimAgirligi = birimAgirligi;
        this.birimFiyati = birimFiyati;
        this.stokMiktari = stokMiktari;
    }

    public String toString() 
    {
    	return adi + " " + kategoriIndex + " " + birimAgirligi + " " + birimFiyati + " " + stokMiktari;
    }
}
