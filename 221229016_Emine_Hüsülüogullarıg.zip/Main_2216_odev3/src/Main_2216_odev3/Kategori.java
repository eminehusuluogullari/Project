package Main_2216_odev3;

class Kategori 
{
    int index;
    int adet;

    public Kategori(int index, int adet) 
    {
        this.index = index;
        this.adet = adet;
    }

    public String toString() 
    {
        return index + " " + adet;
    }
}

