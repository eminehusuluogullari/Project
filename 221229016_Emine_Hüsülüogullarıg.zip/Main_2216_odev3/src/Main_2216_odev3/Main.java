package Main_2216_odev3;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main 
{
    static ArrayList<Urun> urunList = new ArrayList<>();

    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        int secim;

        do {
            System.out.println("********menumuz***********");
            System.out.println("1: listeyi olustur ");
            System.out.println("2: yeni kategori listesini oluşturur");
            System.out.println("3: birim fiyatini guncelle");
            System.out.println("4: yeni urun ekle");
            System.out.println("5: urun sil");
            System.out.println("6: cikisssss");
            System.out.print("secim yapin: ");
            
            secim = scanner.nextInt();

            switch (secim) 
            {
                case 1:
                    ListeOlustur();
                    break;
                    
                case 2:
                    System.out.print("stok adet miktarini giirn (A): ");
                    int A = scanner.nextInt();
                    KategorikGoster(A);
                    break;
                    
                case 3:
                    System.out.print("yuzde kac indirim veya zam yapilsin ");
                    int x = scanner.nextInt();
                    System.out.print("indirim mi yapilsin (true yada false) girin: ");
                    boolean indirimMi = scanner.nextBoolean();
                    BirimFiyatDegistir(x, indirimMi);
                    break;
                    
                case 4:
                    YeniUrunEkle();
                    break;
                    
                case 5:
                    UrunleriSil();
                    break;
                    
                case 6:
                    System.out.println("cikiss yapildii...");
                    break;
                default:
                    System.out.println("hatali giris yaptiniz tekrar deneyin");
            }
            
        } while (secim != 6); //6 fa cikis yapildigi iççin
    }

    public static void ListeOlustur() 
    {
        urunList.clear();  // Listeyi başta boşaltıyoruz
        try (BufferedReader br = new BufferedReader(new FileReader("urunler.txt"))) // okuma kısmı
        {
            String line;
            br.readLine(); // baslik satırlarını atla
            while ((line = br.readLine()) != null) 
            {
                String[] parts = line.split("\t"); // satırları tab la ayırdık
                if (parts.length < 5) 
                {
                    System.out.println("gecersiz satir" + line);
                    continue; // yetrersız sutu vrasa
                }

                String adi = parts[0];
                int kategoriIndex = Integer.parseInt(parts[1]);
                String birimAgirligi = parts[2].trim(); 
                double birimFiyati = Double.parseDouble(parts[3].trim()); // trımele bsolauklaır sıleek al
                int stokMiktari = Integer.parseInt(parts[4].trim()); // aynısı

                // Urunun nesnesi
                Urun urun = new Urun(adi, kategoriIndex, birimAgirligi, birimFiyati, stokMiktari);
                urunList.add(urun); // ekleme
            }
            
            System.out.println("listemiz olsuturuldu yazdirlmaya hazir ");
        } 
        catch (IOException e) 
        {
            System.out.println("Dosya okuma hatası: " + e.getMessage());
        }
        catch (NumberFormatException e)
        {
            System.out.println("Numara format hatası: " + e.getMessage());
        }
        
        // listeyı yazdır ekraana
        for (Urun urun : urunList) // foreach ıle parst part 
        {
            System.out.println(urun);
        }

    }


    public static void KategorikGoster(int A) 
    {
        ArrayList<Kategori> kategoriListesi = new ArrayList<>();
        
        for (Urun urun : urunList) 
        {
            if (urun.stokMiktari > A) 
            {
                boolean kategoriVarMi = false;
                for (Kategori kategori : kategoriListesi) 
                {
                    if (kategori.index == urun.kategoriIndex) 
                    {
                        kategori.adet++;
                        kategoriVarMi = true;
                        break;
                    }
                }
                if (!kategoriVarMi) 
                {
                    kategoriListesi.add(new Kategori(urun.kategoriIndex, 1));
                }
            }
        }

        // olusturgumuz kategrı lıstemızı gosterelım
        for (Kategori kategori : kategoriListesi) //forecah
        {
            System.out.println(kategori);
        }
    }

    public static void BirimFiyatDegistir(int x, boolean indirimMi) 
    {
        // ortalama fıyat lazım
        double toplamFiyat = 0;
        
        for (Urun urun : urunList) 
        {
            toplamFiyat += urun.birimFiyati;
        }
        double ortalamaFiyat = toplamFiyat / urunList.size();

        // ortalamaya en yakın olanın fıyatını bul
        Urun enYakinUrun = null;
        double minFark = Double.MAX_VALUE;
        
        for (Urun urun : urunList) 
        {
            double fark = Math.abs(urun.birimFiyati - ortalamaFiyat);
            if (fark < minFark) 
            {
                minFark = fark;
                enYakinUrun = urun;
            }
        }

        // İindirim yapıuoz yada zam
        if (enYakinUrun != null) 
        {
        	if (indirimMi) {
        	    enYakinUrun.birimFiyati -= enYakinUrun.birimFiyati * x / 100;
        	} else {
        	    enYakinUrun.birimFiyati += enYakinUrun.birimFiyati * x / 100;
        	}

            System.out.println("Birim fiyatı güncellenen ürün: " + enYakinUrun);
        }
    }

    public static void YeniUrunEkle() 
    {
        // en az urunun oldugu kategorıyı bul
        int[] kategoriAdetleri = new int[10]; // Varsayalım 10 kategori var
        for (Urun urun : urunList) 
        {
            kategoriAdetleri[urun.kategoriIndex]++;
        }

        int minKategori = 0;
        for (int i = 1; i < kategoriAdetleri.length; i++) 
        {
            if (kategoriAdetleri[i] < kategoriAdetleri[minKategori]) 
            {
                minKategori = i;
            }
        }

        // agriliği strıng yaaptık unutma
        Urun yeniUrun = new Urun("YeniUrun_" + kategoriAdetleri[minKategori], minKategori, "10 boxes", 0, 0);
        urunList.add(yeniUrun);
        System.out.println("Yeni ürün eklendi: " + yeniUrun);

        // Tüm listeyi göster
        for (Urun urun : urunList) 
        {
            System.out.println(urun);
        }
    }

    public static void UrunleriSil() 
    {
        urunList.removeIf(urun -> urun.stokMiktari == 0); //0 yaoıyz
        
        System.out.println("stok harici urunler silindi.");
        
        for (Urun urun : urunList) //foreach ıle lstele 
        {
            System.out.println(urun);
        }
    }
}
